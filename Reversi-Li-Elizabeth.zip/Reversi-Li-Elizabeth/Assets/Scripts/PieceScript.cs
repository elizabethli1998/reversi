using UnityEngine;
using System.Collections;

public enum PColor {
	None,
	W,
	B
}
public class PieceScript : MonoBehaviour {
	private enum PieceRotation {
		White = 0,
		Black = 180
	}
	[SerializeField]
	private PColor currentColor;
	private Animator anim;
	private GameScript game;
	// Use this for initialization
	void Start ()
  {
		anim = GetComponent<Animator>();
		game = GameObject.Find("Game Camera").GetComponent<GameScript>();
	}
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.A)) Flip();
	}
	public void setColor(PColor color) {
		currentColor = color;
	}
  //Flip opposite
	public PColor Flip() {
		if (currentColor == PColor.W) {
			anim.SetTrigger("Wht2BlkFlip");
      	game.upPlayer();
			currentColor = PColor.B;
		}
		else {
			anim.SetTrigger("Blk2WhtFlip");
      			game.upOpponent();
			currentColor = PColor.W;
		}
		return currentColor;
	}
}
