
using UnityEngine;
using System.Collections;
using static GameScript;
public struct move {
 public int value;
 public int points;
 public int i;
 public int j;
}
public class MiniMax: MonoBehaviour {
 private int[, ] boardVals;
 private GameScript game;
 private int[, ] mainBoard;
 private const int BOARD_SIZE = 7;
 // Use this for initialization
 //Our initial points for the AI
 void Start() {
  boardVals = new int[, ] {
   {
    6,
    1,
    4,
    4,
    4,
    4,
    1,
    6
   }, {
    1,
    1,
    2,
    2,
    2,
    2,
    1,
    1
   }, {
    4,
    2,
    3,
    3,
    3,
    3,
    2,
    4
   }, {
    4,
    2,
    3,
    3,
    3,
    3,
    2,
    4
   }, {
    4,
    2,
    3,
    3,
    3,
    3,
    2,
    4
   }, {
    4,
    2,
    3,
    3,
    3,
    3,
    2,
    4
   }, {
    1,
    1,
    2,
    2,
    2,
    2,
    1,
    1
   }, {
    6,
    1,
    4,
    4,
    4,
    4,
    1,
    6
   }
  };
  game = GetComponent <GameScript>();
 }
 void Update() {
 }

 public move SecondMiniMax(PColor[, ] mainBoard, int depth, bool maxPlayer, int alpha, int beta, int i2, int j2) {
  if ((depth == 0 && !maxPlayer) || (depth == 0 && maxPlayer)) {
   move finalMove;
   finalMove.value = 0;
   finalMove.i = i2;
   finalMove.j = j2;
   finalMove.points = 0;
   return finalMove;
  }
  //Enemy Player
  if (!maxPlayer) {
    move makeAMove;
    makeAMove.i = -1;
    makeAMove.j = -1;
    makeAMove.value = 99999;
    makeAMove.points = 0;
    for (int j = 0; j <= BOARD_SIZE; j++) {
     for (int i = 0; i <= BOARD_SIZE; i++) {
      turningDirectionsForPieces playPiece = game.isValidMove(i, j, PColor.B, mainBoard);
      if (playPiece.down || playPiece.left || playPiece.up || playPiece.right || playPiece.downRight || playPiece.upRight || playPiece.downLeft || playPiece.upLeft) {
       mainBoard[i, j] = PColor.B;
       move decidingMove = SecondMiniMax(mainBoard, depth - 1, true, alpha, beta, i, j);
       decidingMove.value -= boardVals[i, j];
       if (decidingMove.value < makeAMove.value) {
        makeAMove.i = i;
        makeAMove.j = j;
        makeAMove.value = decidingMove.value;
        makeAMove.points = decidingMove.points;
       }
       mainBoard[i, j] = PColor.None;
       beta = Mathf.Min(beta, makeAMove.value);
       if (beta <= alpha) {
        return makeAMove;
       }
      }
     }
    }
    return makeAMove;
  }
  else
  {    move makeAMove;
       makeAMove.value = -99999;
       makeAMove.i = -1;
       makeAMove.j = -1;
       makeAMove.points = -1;
       for (int j = 0; j <= BOARD_SIZE; j++) {
        for (int i = 0; i <= BOARD_SIZE; i++) {
         turningDirectionsForPieces playPiece = game.isValidMove(i, j, PColor.W, mainBoard);
         if (playPiece.down || playPiece.left || playPiece.up || playPiece.right || playPiece.downLeft || playPiece.upLeft || playPiece.downRight || playPiece.upRight) {
          mainBoard[i, j] = PColor.W;
          move decidingMove = SecondMiniMax(mainBoard, depth - 1, false, alpha, beta, i, j);
          decidingMove.value += boardVals[i, j];
          if (decidingMove.value > makeAMove.value) {
           makeAMove.i = i;
           makeAMove.j = j;
           makeAMove.value = decidingMove.value;
          }
          mainBoard[i, j] = PColor.None;
          alpha = Mathf.Max(alpha, makeAMove.value);
          if (beta <= alpha) {
           return makeAMove;
          }
         }
        }
       }
       return makeAMove;
  }
 }
 //Standard minimax algorithm for our player and ai
 public move AlgoMiniMax(PColor[, ] mainBoard, int depth, bool maxPlayer, int alpha, int beta, int i2, int j2) {
  if ((depth == 0 && !maxPlayer) || (depth == 0 && maxPlayer)) {
   move finalMove;
   finalMove.i = i2;
   finalMove.j = j2;
   finalMove.value = 0;
   finalMove.points = 0;
   return finalMove;
  }
  //Opponent
  if (!maxPlayer) {
    move makeAMove;
    makeAMove.i = -1;
    makeAMove.j = -1;
    makeAMove.value = 99999;
    makeAMove.points = -1;
    for (int j = 0; j <= BOARD_SIZE; j++) {
     for (int i = 0; i <= BOARD_SIZE; i++) {
      turningDirectionsForPieces playPiece = game.isValidMove(i, j, PColor.B, mainBoard);
      if (playPiece.down || playPiece.left || playPiece.up || playPiece.right || playPiece.downLeft || playPiece.upLeft || playPiece.downRight || playPiece.upRight) {
       mainBoard[i, j] = PColor.B;
       move decidingMove = AlgoMiniMax(mainBoard, depth - 1, true, alpha, beta, i, j);
       decidingMove.points -= playPiece.points;
       decidingMove.value -= boardVals[i, j];
       if (decidingMove.value == makeAMove.value) {
        if (decidingMove.points < makeAMove.points) {
         makeAMove.i = i;
         makeAMove.j = j;
         makeAMove.value = decidingMove.value;
         makeAMove.points = decidingMove.points;
        }
       }
       else if (decidingMove.value < makeAMove.value) {
        makeAMove.i = i;
        makeAMove.j = j;
        makeAMove.value = decidingMove.value;
        makeAMove.points = decidingMove.points;
       }
       mainBoard[i, j] = PColor.None;
       beta = Mathf.Min(beta, makeAMove.value);
       if (beta <= alpha) {
        return makeAMove;
       }
      }
     }
    }
    return makeAMove;
  }
  //Time for Player
  else {
       move makeAMove;
       makeAMove.i = -1;
       makeAMove.j = -1;
       makeAMove.value = -99999;
       makeAMove.points = -1;
       for (int j = 0; j <= BOARD_SIZE; j++) {
        for (int i = 0; i <= BOARD_SIZE; i++) {
         turningDirectionsForPieces playPiece = game.isValidMove(i, j, PColor.W, mainBoard);
         if (playPiece.down || playPiece.left || playPiece.up || playPiece.right || playPiece.downLeft || playPiece.upLeft || playPiece.downRight || playPiece.upRight) {
          mainBoard[i, j] = PColor.W;
          move decidingMove = AlgoMiniMax(mainBoard, depth - 1, false, alpha, beta, i, j);
          decidingMove.value += boardVals[i, j];
          decidingMove.points += playPiece.points;
          if (decidingMove.value == makeAMove.value) {
           if (decidingMove.points > makeAMove.points) {
            makeAMove.i = i;
            makeAMove.j = j;
            makeAMove.value = decidingMove.value;
            makeAMove.points = decidingMove.points;
           }
          }
          else if (decidingMove.value > makeAMove.value) {
           makeAMove.i = i;
           makeAMove.j = j;
           makeAMove.value = decidingMove.value;
           makeAMove.points = decidingMove.points;
          }
          mainBoard[i, j] = PColor.None;
          alpha = Mathf.Max(alpha, makeAMove.value);
          if (beta <= alpha) {
           return makeAMove;
          }
         }
        }
       }
       return makeAMove;
  }
 }
}
